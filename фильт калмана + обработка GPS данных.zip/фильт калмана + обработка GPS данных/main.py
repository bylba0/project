

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
import os
import folium
from folium.plugins import TimestampedGeoJson
from branca.colormap import LinearColormap

warnings.filterwarnings('ignore')


# ПАПКА ДЛЯ СОХРАНЕНИЯ ВСЕХ ГРАФИКОВ И КАРТ
GRAPH_DIR = 'output_graphs'
os.makedirs(GRAPH_DIR, exist_ok=True)

def gpath(filename):
    return os.path.join(GRAPH_DIR, filename)


# 1. ЗАГРУЗКА И ОЧИСТКА ДАННЫХ


print("=" * 60)
print("ЗАГРУЗКА ДАННЫХ")
print("=" * 60)

df = pd.read_csv("processed_data.csv")
df.columns = df.columns.str.strip()


def safe_float(x):
    try:
        return float(x)
    except:
        return np.nan


df['Engine RPM(rpm)'] = df['Engine RPM(rpm)'].apply(safe_float)
df['Speed (GPS)(km/h)'] = df['Speed (GPS)(km/h)'].apply(safe_float)
df['Litres Per 100 Kilometer(Instant)(l/100km)'] = df[
    'Litres Per 100 Kilometer(Instant)(l/100km)'].apply(safe_float)

def parse_time_col(series):
    """Парсит столбец времени, автоматически определяя формат."""
    formats = [
        '%a %b %d %H:%M:%S GMT+03:00 %Y',   # Wed Mar 25 17:18:15 GMT+03:00 2016
        '%d-%b-%Y %H:%M:%S.%f',              # 25-Mar-2016 17:18:15.000
        '%Y-%m-%d %H:%M:%S',                 # 2016-03-25 17:18:15
        '%Y-%m-%dT%H:%M:%S',                 # ISO 8601
    ]
    for fmt in formats:
        try:
            result = pd.to_datetime(series, format=fmt)
            print(f"  Формат времени: '{fmt}'")
            return result
        except (ValueError, TypeError):
            continue
    # Если ничего не подошло - pandas сам разберётся
    print("  Формат времени: автоопределение (mixed)")
    return pd.to_datetime(series, format='mixed', dayfirst=True)

df['GPS Time']    = parse_time_col(df['GPS Time'])
df['Device Time'] = parse_time_col(df['Device Time'])

df['GPS_Time_sec'] = (df['GPS Time'] - df['GPS Time'].iloc[0]).dt.total_seconds()
df['Device_Time_sec'] = (df['Device Time'] - df['Device Time'].iloc[0]).dt.total_seconds()

# Определяем реальные GPS-обновления (не дубликаты)
df['GPS_Speed_changed'] = df['Speed (GPS)(km/h)'].diff().abs() > 0.01
df['GPS_Lat_changed'] = df['Latitude'].diff().abs() > 0.0000001
df['GPS_updated'] = df['GPS_Speed_changed'] | df['GPS_Lat_changed']
df.loc[0, 'GPS_updated'] = True

print(f"Всего записей: {len(df)}")
print(f"Длительность: {df['Device_Time_sec'].iloc[-1]:.1f} с")
print(f"Реальных GPS-обновлений: {df['GPS_updated'].sum()}")



# 2. РАЗМИНКА: траектория, скорости, bearing, датчики


print("\n" + "=" * 60)
print("РАЗМИНКА")
print("=" * 60)


def latlon_to_meters(lat, lon, lat0, lon0):
    """Перевод географических координат в метры от начальной точки."""
    R = 6371000
    lat_mean = (lat + lat0) / 2
    x = (lon - lon0) * np.pi / 180 * R * np.cos(lat_mean * np.pi / 180)
    y = (lat - lat0) * np.pi / 180 * R
    return x, y


lat0 = df['Latitude'].iloc[0]
lon0 = df['Longitude'].iloc[0]
df['x_meters'], df['y_meters'] = latlon_to_meters(
    df['Latitude'].values, df['Longitude'].values, lat0, lon0
)

#График 1: Траектория
plt.figure(figsize=(12, 10))
plt.plot(df['x_meters'], df['y_meters'], 'b-', linewidth=0.5, alpha=0.7)
plt.scatter(df['x_meters'].iloc[0], df['y_meters'].iloc[0],
            c='green', s=150, marker='o', label='Старт', zorder=5)
plt.scatter(df['x_meters'].iloc[-1], df['y_meters'].iloc[-1],
            c='red', s=150, marker='X', label='Финиш', zorder=5)
plt.xlabel('X, метры (восток)', fontsize=13)
plt.ylabel('Y, метры (север)', fontsize=13)
plt.title('Траектория движения ББМР', fontsize=15, fontweight='bold')
plt.axis('equal')
plt.grid(True, alpha=0.3)
plt.legend(fontsize=12)
plt.tight_layout()
plt.savefig(gpath('trajectory.png'), dpi=300)
plt.show()
print(f"✓ Графики сохранены в папку: ./{GRAPH_DIR}/")

#График 2: Сравнение скоростей
fig, axes = plt.subplots(2, 1, figsize=(15, 8))
gps_data = df[df['GPS_updated']].copy()

axes[0].plot(df['Device_Time_sec'], df['Speed (OBD)(km/h)'],
             'b-', linewidth=0.8, alpha=0.6, label='OBD Speed (~10 Гц)')
axes[0].plot(gps_data['GPS_Time_sec'], gps_data['Speed (GPS)(km/h)'],
             'ro-', linewidth=1, markersize=3, alpha=0.7, label='GPS Speed (реальные, 1 Гц)')
axes[0].set_xlabel('Время (с)', fontsize=12)
axes[0].set_ylabel('Скорость (км/ч)', fontsize=12)
axes[0].set_title('Сравнение скорости OBD vs GPS', fontsize=13, fontweight='bold')
axes[0].legend(fontsize=11)
axes[0].grid(True, alpha=0.3)

gps_speed_interp = np.interp(df['Device_Time_sec'],
                              gps_data['GPS_Time_sec'],
                              gps_data['Speed (GPS)(km/h)'])
df['Speed_diff'] = df['Speed (OBD)(km/h)'] - gps_speed_interp
axes[1].plot(df['Device_Time_sec'], df['Speed_diff'], 'g-', linewidth=0.5, alpha=0.7)
axes[1].axhline(y=0, color='r', linestyle='--', linewidth=1)
axes[1].set_xlabel('Время (с)', fontsize=12)
axes[1].set_ylabel('OBD − GPS (км/ч)', fontsize=12)
axes[1].set_title('Разница скоростей OBD и GPS', fontsize=13, fontweight='bold')
axes[1].grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('speed_comparison.png'), dpi=300)
plt.show()
print("✓ speed_comparison.png")

#График 3: Bearing и компоненты скорости
df['Bearing_rad'] = df['Bearing'] * np.pi / 180
df['Vx_GPS'] = df['Speed (GPS)(km/h)'] / 3.6 * np.sin(df['Bearing_rad'])
df['Vy_GPS'] = df['Speed (GPS)(km/h)'] / 3.6 * np.cos(df['Bearing_rad'])

fig, axes = plt.subplots(3, 1, figsize=(15, 10))
axes[0].plot(df['GPS_Time_sec'], df['Bearing'], 'b-', linewidth=0.8)
axes[0].set_ylabel('Bearing (°)', fontsize=12)
axes[0].set_title('Ориентация ББМР (курс)', fontsize=13, fontweight='bold')
axes[0].grid(True, alpha=0.3)

axes[1].plot(df['GPS_Time_sec'], df['Vx_GPS'], 'r-', linewidth=0.8)
axes[1].axhline(y=0, color='k', linestyle='--', linewidth=1)
axes[1].set_ylabel('Vx (м/с, восток)', fontsize=12)
axes[1].set_title('Компонента скорости по X (восток)', fontsize=13, fontweight='bold')
axes[1].grid(True, alpha=0.3)

axes[2].plot(df['GPS_Time_sec'], df['Vy_GPS'], 'g-', linewidth=0.8)
axes[2].axhline(y=0, color='k', linestyle='--', linewidth=1)
axes[2].set_ylabel('Vy (м/с, север)', fontsize=12)
axes[2].set_xlabel('Время (с)', fontsize=12)
axes[2].set_title('Компонента скорости по Y (север)', fontsize=13, fontweight='bold')
axes[2].grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('bearing_and_velocity_components.png'), dpi=300)
plt.show()
print("✓ bearing_and_velocity_components.png")

#График 4: Прочие датчики
fig, axes = plt.subplots(4, 1, figsize=(15, 12))
axes[0].plot(df['Device_Time_sec'], df['Engine RPM(rpm)'], 'b-', linewidth=0.7)
axes[0].set_ylabel('RPM', fontsize=12)
axes[0].set_title('Обороты двигателя', fontsize=13, fontweight='bold')
axes[0].grid(True, alpha=0.3)

axes[1].plot(df['GPS_Time_sec'], df['Altitude'], 'g-', linewidth=0.7)
axes[1].set_ylabel('Высота (м)', fontsize=12)
axes[1].set_title('Высота над уровнем моря', fontsize=13, fontweight='bold')
axes[1].grid(True, alpha=0.3)

axes[2].plot(df['Device_Time_sec'], df['Acceleration Sensor(Total)(g)'], 'r-', linewidth=0.7)
axes[2].axhline(y=1, color='k', linestyle='--', linewidth=1, alpha=0.5, label='1g (покой)')
axes[2].set_ylabel('Ускорение (g)', fontsize=12)
axes[2].set_title('Полное ускорение (Total)', fontsize=13, fontweight='bold')
axes[2].legend(fontsize=11)
axes[2].grid(True, alpha=0.3)

axes[3].plot(df['Device_Time_sec'], df['Acceleration Sensor(Z axis)(g)'], 'm-', linewidth=0.7)
axes[3].axhline(y=1, color='k', linestyle='--', linewidth=1, alpha=0.5, label='1g (покой)')
axes[3].set_ylabel('Ускор. Z (g)', fontsize=12)
axes[3].set_xlabel('Время (с)', fontsize=12)
axes[3].set_title('Ускорение по оси Z (вертикаль)', fontsize=13, fontweight='bold')
axes[3].legend(fontsize=11)
axes[3].grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('other_sensors.png'), dpi=300)
plt.show()
print("✓ other_sensors.png")

# Сохраняем промежуточные данные
df.to_csv('processed_data.csv', index=False)
print("\n✓ processed_data.csv сохранён")


# 3. ЧАСТЬ 1: ОДНОМЕРНЫЙ ФИЛЬТР КАЛМАНА ДЛЯ СКОРОСТИ


print("\n" + "=" * 60)
print("ЧАСТЬ 1: Фильтр Калмана для скорости (20 Гц)")
print("=" * 60)

#Параметры фильтра
# Q: дисперсия процесса - скорость может меняться на ~0.35 км/ч за 0.05 с
Q_speed = 0.1225    # (км/ч)² на шаг 0.05 с
R_obd = 0.5         # (км/ч)² - OBD точнее, меньший шум
R_gps = 2.0         # (км/ч)² - GPS менее точный по скорости

print(f"Q = {Q_speed}, R_obd = {R_obd}, R_gps = {R_gps}")

# Регулярная сетка 20 Гц
dt_grid = 0.05
t_min = df['Device_Time_sec'].min()
t_max = df['Device_Time_sec'].max()
t_grid = np.arange(t_min, t_max + dt_grid, dt_grid)

# Интерполяция измерений на сетку (только для значений, маски определят, что реальное)
obd_interp = np.interp(t_grid, df['Device_Time_sec'], df['Speed (OBD)(km/h)'])
gps_interp = np.interp(t_grid, df['GPS_Time_sec'], df['Speed (GPS)(km/h)'])

# Маски: есть ли реальное измерение в данный момент сетки
obd_times = df['Device_Time_sec'].values
gps_times_real = df[df['GPS_updated']]['GPS_Time_sec'].values

def make_mask(t_grid, event_times, atol=0.025):
    """
    Для каждой точки t_grid проверяет, есть ли ближайший элемент
    из event_times в пределах atol.
    """
    event_times = np.sort(event_times)
    idx = np.searchsorted(event_times, t_grid)
    mask = np.zeros(len(t_grid), dtype=bool)
    for shift in (0, -1):   # проверяем ближайшего справа и слева
        j = idx + shift
        valid = (j >= 0) & (j < len(event_times))
        close = np.zeros(len(t_grid), dtype=bool)
        close[valid] = np.abs(t_grid[valid] - event_times[j[valid]]) <= atol
        mask |= close
    return mask

obd_mask  = make_mask(t_grid, obd_times)
gps_mask  = make_mask(t_grid, gps_times_real)

# Временные интервалы пропаданий
exp_start_time = df['GPS Time'].iloc[0]


def time_to_sec(t_str):
    """Перевод времени 'ЧЧ:ММ' в секунды от начала эксперимента."""
    t = datetime.combine(exp_start_time.date(), datetime.strptime(t_str, "%H:%M").time())
    return (t - exp_start_time).total_seconds()


dropout_gps_start = time_to_sec("17:25")
dropout_gps_end   = time_to_sec("17:35")
dropout_obd_start = time_to_sec("17:40")
dropout_obd_end   = time_to_sec("17:50")

print(f"Пропадание GPS: {dropout_gps_start:.0f}–{dropout_gps_end:.0f} с")
print(f"Пропадание OBD: {dropout_obd_start:.0f}–{dropout_obd_end:.0f} с")

#  Запуск фильтра
x_speed = 0.0
P_speed = 1.0
estimates_speed = []
cov_speed = []

for i, t in enumerate(t_grid):
    # PREDICT: неопределённость растёт с каждым шагом
    P_speed += Q_speed * dt_grid

    # Флаги наличия реальных измерений с учётом пропаданий
    use_obd = obd_mask[i] and not (dropout_obd_start <= t <= dropout_obd_end)
    use_gps = gps_mask[i] and not (dropout_gps_start <= t <= dropout_gps_end)

    # UPDATE по OBD
    if use_obd:
        z = obd_interp[i]
        K = P_speed / (P_speed + R_obd)
        x_speed = x_speed + K * (z - x_speed)
        P_speed = (1 - K) * P_speed

    # UPDATE по GPS (только реальные 1-Гц обновления)
    if use_gps:
        z = gps_interp[i]
        K = P_speed / (P_speed + R_gps)
        x_speed = x_speed + K * (z - x_speed)
        P_speed = (1 - K) * P_speed

    estimates_speed.append(x_speed)
    cov_speed.append(P_speed)

estimates_speed = np.array(estimates_speed)
std_speed = np.sqrt(np.array(cov_speed))

print(f"✓ Фильтр скорости завершён ({len(t_grid)} шагов)")

#График 5: Полная оценка скорости
plt.figure(figsize=(14, 6))
plt.plot(t_grid, estimates_speed, 'b-', linewidth=1.5, label='Оценка Калмана', zorder=3)
plt.fill_between(t_grid,
                 estimates_speed - 3 * std_speed,
                 estimates_speed + 3 * std_speed,
                 color='b', alpha=0.2, label='±3σ', zorder=1)
plt.scatter(df['Device_Time_sec'], df['Speed (OBD)(km/h)'],
            s=1, c='g', label='OBD', alpha=0.6, zorder=2)
plt.scatter(gps_times_real,
            np.interp(gps_times_real, t_grid, gps_interp),
            s=10, c='r', label='GPS (реальные)', alpha=0.8, zorder=4)
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Скорость (км/ч)', fontsize=13)
plt.title('Фильтр Калмана для скорости — полная запись (20 Гц)', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('speed_kalman_full.png'), dpi=300)
plt.show()
print("✓ speed_kalman_full.png")

#График 6: Зум на детальный участок
zoom_start, zoom_end = 600, 800
zoom_mask = (t_grid >= zoom_start) & (t_grid <= zoom_end)
plt.figure(figsize=(14, 6))
plt.plot(t_grid[zoom_mask], estimates_speed[zoom_mask], 'b-', linewidth=2, label='Оценка Калмана')
plt.fill_between(t_grid[zoom_mask],
                 estimates_speed[zoom_mask] - 3 * std_speed[zoom_mask],
                 estimates_speed[zoom_mask] + 3 * std_speed[zoom_mask],
                 color='b', alpha=0.2, label='±3σ')
obd_zoom = df[(df['Device_Time_sec'] >= zoom_start) & (df['Device_Time_sec'] <= zoom_end)]
plt.scatter(obd_zoom['Device_Time_sec'], obd_zoom['Speed (OBD)(km/h)'],
            s=10, c='g', label='OBD', alpha=0.7)
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Скорость (км/ч)', fontsize=13)
plt.title(f'Детальный вид оценки скорости ({zoom_start}–{zoom_end} с)', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('speed_kalman_zoom.png'), dpi=300)
plt.show()
print("✓ speed_kalman_zoom.png")

#График 7: Пропадание GPS
plt.figure(figsize=(14, 6))
plt.plot(t_grid, estimates_speed, 'b-', linewidth=1.2, label='Оценка Калмана')
plt.fill_between(t_grid,
                 estimates_speed - 3 * std_speed,
                 estimates_speed + 3 * std_speed,
                 color='b', alpha=0.2, label='±3σ')
plt.axvspan(dropout_gps_start, dropout_gps_end,
            alpha=0.25, color='orange', label='Пропадание GPS (17:25–17:35)')
plt.scatter(df['Device_Time_sec'], df['Speed (OBD)(km/h)'],
            s=1, c='g', label='OBD', alpha=0.5)
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Скорость (км/ч)', fontsize=13)
plt.title('Эффект пропадания GPS на оценку скорости', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('speed_kalman_gps_dropout.png'), dpi=300)
plt.show()
print("✓ speed_kalman_gps_dropout.png")

#График 8: Пропадание OBD
plt.figure(figsize=(14, 6))
plt.plot(t_grid, estimates_speed, 'b-', linewidth=1.2, label='Оценка Калмана')
plt.fill_between(t_grid,
                 estimates_speed - 3 * std_speed,
                 estimates_speed + 3 * std_speed,
                 color='b', alpha=0.2, label='±3σ')
plt.axvspan(dropout_obd_start, dropout_obd_end,
            alpha=0.25, color='red', label='Пропадание OBD (17:40–17:50)')
plt.scatter(gps_times_real,
            np.interp(gps_times_real, t_grid, gps_interp),
            s=10, c='r', label='GPS', alpha=0.8)
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Скорость (км/ч)', fontsize=13)
plt.title('Эффект пропадания OBD на оценку скорости', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('speed_kalman_obd_dropout.png'), dpi=300)
plt.show()
print("✓ speed_kalman_obd_dropout.png")


# 4. ЧАСТЬ 2: ОДНОМЕРНЫЙ ФИЛЬТР КАЛМАНА ДЛЯ ПОЛОЖЕНИЯ


print("\n" + "=" * 60)
print("ЧАСТЬ 2: Фильтр Калмана для положения по ДОЛГОТЕ (восток)")
print("=" * 60)


class KalmanFilter1D:
    """Одномерный фильтр Калмана для оценки координаты (м)."""

    def __init__(self, x0, P0, Q, R):
        self.x = x0
        self.P = P0
        self.Q = Q   # шум процесса (м²/с)
        self.R = R   # шум измерений GPS (м²)

    def predict(self, v_axis_ms, dt):
        """v_axis_ms — проекция скорости на нужную ось (м/с)."""
        self.x += v_axis_ms * dt
        self.P += self.Q * dt

    def update(self, z):
        """z — GPS-измерение координаты в метрах."""
        K = self.P / (self.P + self.R)
        self.x += K * (z - self.x)
        self.P = (1 - K) * self.P
        return K


# Параметры
Q_pos = 0.5   # м²/с
R_pos = 4.0   # м² (~±2 м точность GPS)
print(f"Q = {Q_pos} м²/с,  R = {R_pos} м²")

# Скорость и bearing на сетке t_grid
speed_ms_grid    = np.interp(t_grid, df['Device_Time_sec'],
                              df['Speed (OBD)(km/h)']) / 3.6
bearing_rad_grid = np.interp(t_grid, df['GPS_Time_sec'], df['Bearing_rad'])

# GPS-измерения (только реальные обновления)
gps_df    = df[df['GPS_updated']].copy()
gps_t_arr = gps_df['GPS_Time_sec'].values
gps_x_arr = gps_df['x_meters'].values   # восток (долгота)
gps_y_arr = gps_df['y_meters'].values   # север  (широта)

# Фильтр по X (долгота, восток)
kf_x = KalmanFilter1D(x0=0.0, P0=1.0, Q=Q_pos, R=R_pos)
est_x, cov_x, meas_x = [], [], []
last_t = t_grid[0]

for i, t in enumerate(t_grid):
    dt_step = t - last_t if i > 0 else 0.0
    if dt_step > 0:
        # Восточная компонента скорости: V * sin(Bearing)
        v_east = speed_ms_grid[i - 1] * np.sin(bearing_rad_grid[i - 1])
        kf_x.predict(v_east, dt_step)
    if gps_mask[i] and not (dropout_gps_start <= t <= dropout_gps_end):
        z = np.interp(t, gps_t_arr, gps_x_arr)
        kf_x.update(z)
        meas_x.append((t, z))
    est_x.append(kf_x.x)
    cov_x.append(kf_x.P)
    last_t = t

est_x  = np.array(est_x)
std_x  = np.sqrt(np.array(cov_x))

# Фильтр по Y (широта, север) - для сравнения
kf_y = KalmanFilter1D(x0=0.0, P0=1.0, Q=Q_pos, R=R_pos)
est_y, cov_y, meas_y = [], [], []
last_t = t_grid[0]

for i, t in enumerate(t_grid):
    dt_step = t - last_t if i > 0 else 0.0
    if dt_step > 0:
        # Северная компонента скорости: V * cos(Bearing)
        v_north = speed_ms_grid[i - 1] * np.cos(bearing_rad_grid[i - 1])
        kf_y.predict(v_north, dt_step)
    if gps_mask[i] and not (dropout_gps_start <= t <= dropout_gps_end):
        z = np.interp(t, gps_t_arr, gps_y_arr)
        kf_y.update(z)
        meas_y.append((t, z))
    est_y.append(kf_y.x)
    cov_y.append(kf_y.P)
    last_t = t

est_y  = np.array(est_y)
std_y  = np.sqrt(np.array(cov_y))

print(f"✓ Фильтры завершены")
print(f"  X (восток): {est_x[-1]:.1f} м,  ±3σ среднее: ±{(3*std_x).mean():.2f} м")
print(f"  Y (север):  {est_y[-1]:.1f} м,  ±3σ среднее: ±{(3*std_y).mean():.2f} м")

# ── График 9: Фильтр по X (долгота) — полная запись ─────────
plt.figure(figsize=(14, 6))
plt.plot(t_grid, est_x, 'b-', linewidth=1.5, label='Оценка Калмана (X)', zorder=3)
plt.fill_between(t_grid, est_x - 3*std_x, est_x + 3*std_x,
                 color='b', alpha=0.2, label='±3σ', zorder=1)
if meas_x:
    mx_t, mx_z = zip(*meas_x)
    plt.scatter(mx_t, mx_z, s=12, c='r', marker='x',
                label='GPS (долгота)', alpha=0.7, zorder=4)
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Смещение на восток (м)', fontsize=13)
plt.title('Фильтр Калмана для положения по ДОЛГОТЕ (восток) — полная запись',
          fontsize=13, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('position_kalman_full.png'), dpi=300)
plt.show()
print("✓ position_kalman_full.png")

#График 10: Зум - фазы predict/update
zoom_start2, zoom_end2 = 200, 260
zm = (t_grid >= zoom_start2) & (t_grid <= zoom_end2)

fig, axes = plt.subplots(1, 2, figsize=(16, 5))
for ax, est, std, meas, label, color, ylabel in [
    (axes[0], est_x[zm], std_x[zm], meas_x, 'X (восток / долгота)', 'blue',  'Смещение на восток (м)'),
    (axes[1], est_y[zm], std_y[zm], meas_y, 'Y (север / широта)',   'green', 'Смещение на север (м)'),
]:
    ax.plot(t_grid[zm], est, '-', color=color, linewidth=2, label=f'Калман {label}')
    ax.fill_between(t_grid[zm], est - 3*std, est + 3*std,
                    color=color, alpha=0.2, label='±3σ')
    # GPS-точки в зуме
    if meas:
        mt, mz = zip(*meas)
        mt, mz = np.array(mt), np.array(mz)
        zm_gps = (mt >= zoom_start2) & (mt <= zoom_end2)
        if zm_gps.any():
            ax.scatter(mt[zm_gps], mz[zm_gps], s=60, c='r', marker='x',
                       linewidths=2, label='GPS', zorder=5)
    ax.set_xlabel('Время (с)', fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_title(f'Детальный вид: {label} ({zoom_start2}–{zoom_end2} с)', fontsize=11)
    ax.legend(fontsize=10)
    ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig(gpath('position_kalman_zoom.png'), dpi=300)
plt.show()
print("✓ position_kalman_zoom.png")

#График 11: Пропадание GPS - эффект на X (долготу)
plt.figure(figsize=(14, 6))
plt.plot(t_grid, est_x, 'b-', linewidth=1.2, label='Оценка Калмана (X)')
plt.fill_between(t_grid, est_x - 3*std_x, est_x + 3*std_x,
                 color='b', alpha=0.2, label='±3σ')
plt.axvspan(dropout_gps_start, dropout_gps_end,
            alpha=0.25, color='orange', label='Пропадание GPS (17:25–17:35)')
if meas_x:
    mx_t2, mx_z2 = zip(*meas_x)
    plt.scatter(mx_t2, mx_z2, s=6, c='r', alpha=0.6, label='GPS (долгота)')
plt.xlabel('Время (с)', fontsize=13)
plt.ylabel('Смещение на восток (м)', fontsize=13)
plt.title('Влияние пропадания GPS на оценку положения по долготе',
          fontsize=13, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(gpath('position_kalman_gps_dropout.png'), dpi=300)
plt.show()
print("✓ position_kalman_gps_dropout.png")


# 5. ИНТЕРАКТИВНЫЕ КАРТЫ FOLIUM


print("\n" + "=" * 60)
print("КАРТЫ FOLIUM")
print("=" * 60)

gps_pts = df[df['GPS_updated']].copy()
trajectory = list(zip(gps_pts['Latitude'], gps_pts['Longitude']))

# 5.1 Базовая карта с маршрутом
m_base = folium.Map(location=[df['Latitude'].mean(), df['Longitude'].mean()], zoom_start=14)
folium.PolyLine(trajectory, color='blue', weight=3, opacity=0.8).add_to(m_base)
folium.Marker(trajectory[0], popup="Старт", icon=folium.Icon(color='green')).add_to(m_base)
folium.Marker(trajectory[-1], popup="Финиш", icon=folium.Icon(color='red')).add_to(m_base)
m_base.save(gpath("trajectory_map.html"))
print("✓ trajectory_map.html")

# 5.2 Анимированная карта
gps_pts['time_iso'] = gps_pts['GPS Time'].dt.strftime('%Y-%m-%dT%H:%M:%SZ')
features = []
for _, row in gps_pts.iterrows():
    features.append({
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [row['Longitude'], row['Latitude']]},
        "properties": {
            "time": row['time_iso'],
            "popup": f"Время: {row['GPS Time'].strftime('%H:%M:%S')}<br>"
                     f"Скорость: {row['Speed (GPS)(km/h)']:.1f} км/ч",
            "icon": "circle",
            "iconstyle": {"fillColor": "red", "fillOpacity": 0.8, "stroke": "true", "radius": 6}
        }
    })
m_anim = folium.Map(location=[gps_pts['Latitude'].mean(), gps_pts['Longitude'].mean()], zoom_start=15)
folium.PolyLine(trajectory, color='gray', weight=2, opacity=0.5).add_to(m_anim)
TimestampedGeoJson(
    {"type": "FeatureCollection", "features": features},
    period="PT1S", add_last_point=True, auto_play=True,
    loop=False, max_speed=1, loop_button=True,
    date_options="HH:mm:ss", time_slider_drag_update=True
).add_to(m_anim)
folium.Marker(trajectory[0], popup="Старт", icon=folium.Icon(color='green', icon='play', prefix='fa')).add_to(m_anim)
folium.Marker(trajectory[-1], popup="Финиш", icon=folium.Icon(color='red', icon='stop', prefix='fa')).add_to(m_anim)
m_anim.save(gpath("robot_animation.html"))
print("✓ robot_animation.html")

# 5.3 Траектория, окрашенная по скорости
speed_vals = gps_pts['Speed (GPS)(km/h)'].dropna()
vmin, vmax = speed_vals.min(), speed_vals.max()
if vmin == vmax:
    vmin, vmax = vmin - 0.1, vmax + 0.1

colormap = LinearColormap(
    colors=['blue', 'cyan', 'lime', 'yellow', 'red'],
    vmin=vmin, vmax=vmax, caption='Скорость (км/ч)'
)
m_color = folium.Map(location=[gps_pts['Latitude'].mean(), gps_pts['Longitude'].mean()], zoom_start=15)
for i in range(len(gps_pts) - 1):
    lat1, lon1 = gps_pts.iloc[i]['Latitude'], gps_pts.iloc[i]['Longitude']
    lat2, lon2 = gps_pts.iloc[i + 1]['Latitude'], gps_pts.iloc[i + 1]['Longitude']
    speed = gps_pts.iloc[i]['Speed (GPS)(km/h)']
    color = colormap(speed) if not pd.isna(speed) else 'gray'
    folium.PolyLine([(lat1, lon1), (lat2, lon2)], color=color, weight=5, opacity=0.9,
                    popup=f"Скорость: {speed:.1f} км/ч" if not pd.isna(speed) else "—").add_to(m_color)
folium.Marker(trajectory[0], popup="Старт", icon=folium.Icon(color='green', icon='play', prefix='fa')).add_to(m_color)
folium.Marker(trajectory[-1], popup="Финиш", icon=folium.Icon(color='red', icon='stop', prefix='fa')).add_to(m_color)
colormap.add_to(m_color)
m_color.save(gpath("trajectory_speed_colored.html"))
print("✓ trajectory_speed_colored.html")

# 5.4 Траектория, окрашенная по высоте
alt_vals = gps_pts['Altitude'].dropna()
vmin_a, vmax_a = alt_vals.min(), alt_vals.max()
if vmin_a == vmax_a:
    vmin_a, vmax_a = vmin_a - 1, vmax_a + 1
colormap_alt = LinearColormap(
    colors=['blue', 'cyan', 'green', 'yellow', 'red'],
    vmin=vmin_a, vmax=vmax_a, caption='Высота (м)'
)
m_alt = folium.Map(location=[gps_pts['Latitude'].mean(), gps_pts['Longitude'].mean()], zoom_start=15)
for i in range(len(gps_pts) - 1):
    lat1, lon1 = gps_pts.iloc[i]['Latitude'], gps_pts.iloc[i]['Longitude']
    lat2, lon2 = gps_pts.iloc[i + 1]['Latitude'], gps_pts.iloc[i + 1]['Longitude']
    alt = gps_pts.iloc[i]['Altitude']
    color = colormap_alt(alt) if not pd.isna(alt) else 'gray'
    folium.PolyLine([(lat1, lon1), (lat2, lon2)], color=color, weight=5, opacity=0.9,
                    popup=f"Высота: {alt:.1f} м" if not pd.isna(alt) else "—").add_to(m_alt)
folium.Marker(trajectory[0], popup="Старт", icon=folium.Icon(color='green')).add_to(m_alt)
folium.Marker(trajectory[-1], popup="Финиш", icon=folium.Icon(color='red')).add_to(m_alt)
colormap_alt.add_to(m_alt)
m_alt.save(gpath("trajectory_altitude_colored.html"))
print("✓ trajectory_altitude_colored.html")


# 6. ИТОГОВАЯ СТАТИСТИКА


print("\n" + "=" * 60)
print("ИТОГОВАЯ СТАТИСТИКА")
print("=" * 60)

print(f"\nФильтр скорости:")
print(f"  Средняя оценка: {estimates_speed.mean():.2f} км/ч")
print(f"  Средний ±3σ:    ±{(3*std_speed).mean():.3f} км/ч")
print(f"  Мин / макс:     {estimates_speed.min():.1f} / {estimates_speed.max():.1f} км/ч")

print(f"\nФильтр положения:")
print(f"  X (восток): итог {est_x[-1]:.1f} м,  ±3σ среднее ±{(3*std_x).mean():.2f} м")
print(f"  Y (север):  итог {est_y[-1]:.1f} м,  ±3σ среднее ±{(3*std_y).mean():.2f} м")

print("\n" + "=" * 60)
saved = [
    'trajectory.png', 'speed_comparison.png',
    'bearing_and_velocity_components.png', 'other_sensors.png',
    'speed_kalman_full.png', 'speed_kalman_zoom.png',
    'speed_kalman_gps_dropout.png', 'speed_kalman_obd_dropout.png',
    'position_kalman_full.png', 'position_kalman_zoom.png',
    'position_kalman_gps_dropout.png',
    'trajectory_map.html', 'robot_animation.html',
    'trajectory_speed_colored.html', 'trajectory_altitude_colored.html',
]
for name in saved:
    full_path = gpath(name)
    exists = '✓' if os.path.exists(full_path) else '✗ НЕ НАЙДЕН'
    print(f"  {exists}  {name}")
print(f"\nДанные: processed_data.csv (в текущей папке)")